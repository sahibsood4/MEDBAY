Problem on which our team have worked on 

First selecting the suitable medicine for the type of illness usually take time and makes the customer
or patient waiting , therefore the time is waste for the customer to be waiting. 

Second for the medicine stock management pharmacy must check it manually and no warning message for
medicine that decreases to finish, so MEDBAY provide advantage to setup the process in selecting
and alert program to warn about the medicine stock.

Finally, yet important, no analysis is done for the prices of medicine usually buy by the customer or
patient at that area which is done in MEDBAY, this is also important to determine the medicine that
are demanded more from the customers so that we can be prepared to order more for that type of
medicine

Nowadays, health has became a great matter of concern. Due to the various disease spreading
around us no one is safe in today’s scenario.
As we can see as in today the pandemic has hit our country and worldwide too and the lockdown
has been imposed so it is not safe for people to go outside to buy anything specially medicines
because the medical stores are the prime location from where the virus can get spreaded but it is
a compulsory component so it has to be opened and medicines are life-savers.

In healthcare, the information around our medicines either unavailable or incomprehensible to
us. There are lots of shop out there which sells medicine on their own price and handover the
wrong medicine sometimes and sells the expensive medicines just to earn money.

Health is a major player in a person’s life. So in order to get the necessary things even during the
worst case scenario a firm solution for preventing this problem is a must.

REQUIREMENTS

We have used 

        -- Python as a Backend Language
        
        -- HTML & CSS as a Frontend Language
        
        -- Django as a Framework
        
        -- dbsqlite as Database
        
